package com.appian.robot.core.template;

import java.io.File;
import java.io.IOException;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.io.FilenameUtils;

import com.appian.robot.core.falcon.FalconManager;
import com.appian.robot.core.falcon.ImageResult;
import com.novayre.jidoka.client.api.IImageResource;
import com.novayre.jidoka.client.api.IJidokaServer;
import com.novayre.jidoka.client.api.IRobot;
import com.novayre.jidoka.client.api.IWaitFor;
import com.novayre.jidoka.client.api.JidokaFactory;
import com.novayre.jidoka.client.api.annotations.Robot;
import com.novayre.jidoka.falcon.api.IFalcon;
import com.novayre.jidoka.falcon.api.IFalconImage;
import com.novayre.jidoka.windows.api.EShowWindowState;
import com.novayre.jidoka.windows.api.IWindows;

/**
 * The Class RobotFalconTemplate.
 */
@Robot
public class WPSRobot implements IRobot {

	/** The server. */
	private IJidokaServer< ? > server;

	/** The falcon. */
	private IFalcon falcon;

	/** The client. */
	private IWindows windows;

	private JidokaImageSupport images;

	private FalconManager falconManager;

	private List<IFalconImage> imagesWPOSOT;

	private List<IFalconImage> imagesWPSOTB;

	private IWaitFor waitFor;

	private IFalconImage imageToOpen;

	/**
	 * Initialize the modules
	 * @throws IOException 
	 */
	public void start() throws IOException {

		server = JidokaFactory.getServer();

		windows = IWindows.getInstance(this);

		falcon = IFalcon.getInstance(this, windows);

		images = JidokaImageSupport.getInstance(this);

		falconManager = new FalconManager(this, falcon);

		waitFor = windows.getWaitFor(this);

		server.setNumberOfItems(5);


	}

	/**
	 * 
	 * @throws Exception
	 */
	public void readExcel() throws Exception{
		server.debug("readExcel");

		//Instead open a Excel file, I am going to open a paint tool
		imageToOpen = falconManager.getImage(Paths.get(server.getCurrentDir(), "img", "background.png"));

		this.openFalconImgInPaint(imageToOpen);
	}
	/**
	 * 
	 * @throws Exception
	 */
	public void loginVdesk7() throws Exception{
		server.debug("loginVdesk7");
	}

	/**
	 * 
	 * @throws Exception
	 */
	public void loginNice() throws Exception{
		server.debug("loginNice");
	}

	/**
	 * 
	 * @throws Exception
	 */
	public void manipulate() throws Exception{
		server.debug("manipulate");
	}

	public void confirmation() throws Exception{
		server.debug("Confirmation Category & Location");
	}

	public void select() throws Exception{

		server.debug("select");

		imagesWPOSOT = new ArrayList<IFalconImage>();

		ImageResult imaageR  = null;

		//		//populate Images to search into imagesWPOSOT array
		falconManager.initImagesToSearch(imagesWPOSOT, "WPOSOT");

		imaageR = falconManager.findImage(imagesWPOSOT);

		server.setCurrentItem(1, images.getTestPng().getDescription());

		if (imaageR.isFound()) {
			server.info("Found it");

			imaageR.getImageFound().mouseMoveToCenter();

			server.setCurrentItemResultToOK(imaageR.getImageFound().getDescription());

			//imaageR.getImageFound().clickOnCenter();
		}else {
			server.setCurrentItemResultToWarn();
		}

		//Populate WPSOTB folder images
		imagesWPOSOT = new ArrayList<IFalconImage>();

		falconManager.initImagesToSearch(imagesWPOSOT, "WPSOTB");

		server.setCurrentItem(2, images.getTestPng().getDescription());

		imaageR = falconManager.findImage(imagesWPOSOT);

		if (imaageR.isFound()) {
			server.info("Found it");
			imaageR.getImageFound().mouseMoveToCenter();

			server.setCurrentItemResultToOK(imaageR.getImageFound().getDescription());

			//imaageR.getImageFound().clickOnCenter();
		}else {
			server.setCurrentItemResultToWarn();
		}


		//Populate WPSOTS folder images
		imagesWPOSOT = new ArrayList<IFalconImage>();

		falconManager.initImagesToSearch(imagesWPOSOT, "WPSOTS");

		server.setCurrentItem(3, "Image 3");

		imaageR = falconManager.findImage(imagesWPOSOT);

		if (imaageR.isFound()) {
			server.info("Found it");

			imaageR.getImageFound().mouseMoveToCenter();

			falconManager.sendImage(imaageR);

			server.setCurrentItemResultToOK(imaageR.getImageFound().getDescription());

			//imaageR.getImageFound().clickOnCenter();
		}else {
			server.setCurrentItemResultToWarn();
		}

		//Scond Approach

		IFalconImage[] popupWin =  new IFalconImage[imagesWPOSOT.size()] ;

		server.setCurrentItem(4, images.getTestPng().getDescription());

		popupWin = imagesWPOSOT.toArray(popupWin);

		IImageResource image = waitFor.image(2, false, popupWin );

		if (image.satisfied()) {

			image.mouseMoveToCenter();

			server.setCurrentItemResultToOK(imaageR.getImageFound().getDescription());
			//	server.info("Click on Image");

			//image.click();
		}else {
			server.setCurrentItemResultToWarn();
		}

		//Third approach
		server.setCurrentItem(5, images.getTestPng().getDescription());

		boolean output = windows.waitCondition(5, 2000, "Waiting image", null, true,
				(i, c) -> {
					try {
						return falconManager.findImage(imagesWPOSOT).isFound();
					} catch (Exception e) {
						server.error(e.getMessage());
					}
					return false;
				});

		if (output) {
			
			image.mouseMoveToCenter();

			server.setCurrentItemResultToOK(imaageR.getImageFound().getDescription());
					
		}else {
			server.setCurrentItemResultToWarn();
		}

	}

	@Override
	public String[] cleanUp() throws Exception {

		windows.killProcess("mspaint.exe");
		return IRobot.super.cleanUp();
	}

	/**
	 * End.
	 */
	public void end() {

	}

	/**
	 * Open a falcon image
	 * @param imageToOpen
	 * @throws IOException
	 */
	private void openFalconImgInPaint(IFalconImage imageToOpen) throws Exception {

		ProcessBuilder pb = new ProcessBuilder("mspaint.exe", imageToOpen.getOptions().getFile().getAbsolutePath());

		pb.start();

		// Wait during 10 seconds until the application window is present
		if (windows.waitFor(this).window(3, ".*Paint") != null) {
			windows.showWindow(windows.getWindow(".*Paint").
					gethWnd(), EShowWindowState.SW_MAXIMIZE);
		}
	}




	/**
	 * Open a file in paint
	 * @param imageToOpen
	 * @throws IOException
	 * @throws InterruptedException 
	 */
	public void openImgInPaint(String imagePath) throws Exception {

		ProcessBuilder pb = new ProcessBuilder("mspaint.exe", imagePath);

		pb.start();

		// Wait during 10 seconds until the application window is present
		if (windows.waitFor(this).window(3, ".*Paint") != null) {
			windows.showWindow(windows.getWindow(".*Paint").
					gethWnd(), EShowWindowState.SW_MAXIMIZE);
		}

	}




	/**
	 * Add the suffix to the file name
	 * @param filename
	 * @param suffix
	 * @return File name with suffix
	 */
	public String addSuffix(String filename, String suffix) {

		String baseName = FilenameUtils.getBaseName(filename);
		baseName += suffix;

		String output = FilenameUtils.getFullPath(filename) + File.separator + baseName + "."
				+ FilenameUtils.getExtension(filename);

		return output;
	}


}
