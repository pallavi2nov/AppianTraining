package com.appian.robot.core.falcon;

import java.io.IOException;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import com.novayre.jidoka.client.api.IJidokaServer;
import com.novayre.jidoka.client.api.IRobot;
import com.novayre.jidoka.client.api.JidokaFactory;
import com.novayre.jidoka.falcon.api.FalconImageOptions;
import com.novayre.jidoka.falcon.api.IFalcon;
import com.novayre.jidoka.falcon.api.IFalconImage;
import com.novayre.jidoka.windows.api.IWindows;

/**
 * Jidoka image support
 * 
 *
 */
public class ImageSupport {
	
	/**
	 * Instance
	 */
	private static ImageSupport instance;
	
	/**
	 * Server
	 */
	private final IJidokaServer< ? > server;
	
	/**
	 * Falcon
	 */
	private final IFalcon falcon;
	
	/**
	 * Images
	 */
	private final Map<String, IFalconImage> images = new HashMap<>();
	
	/**
	 * Constructor
	 * @param robot	robot
	 */
	public ImageSupport(IRobot robot) {
		
		server = JidokaFactory.getServer();
		
		falcon = IFalcon.getInstance(robot, IWindows.getInstance(robot));
	}
	
	/**
	 * Returns instance of class
	 * @param robot	robot
	 * @return
	 */
	public static ImageSupport getInstance(IRobot robot) {
		
		if (instance == null) {
			instance = new ImageSupport(robot);
		}
		
		return instance;
	}
	
	/**
	 * Returns a falcon image from specified path
	 * @param path
	 * @return
	 * @throws IOException
	 */
	public IFalconImage getImage(Path path) throws IOException {

		IFalconImage image = images.get(path.toString());
		
		if (image == null) {
			
			image = falcon.getImage(new FalconImageOptions().description(path.getFileName().toString())
					.file(path.toFile()).colorTolerance(.05f));
			
			images.put(path.toString(), image);
		}
		
		image.setPointsWhereFound(new ArrayList<>());
		
		return image;
	}
	
	
}
